# Jiasmin AI Browser Pro (Android)

A WebView app that bundles the Jiasmin page (app/src/main/assets/index.html).

## Get the APK without Android Studio
1. Create a free GitHub account and a new PRIVATE repository.
2. Upload everything in this folder (keep the .github folder).
3. Open the Actions tab, run "Build APK", wait about 5 minutes.
4. Download "Jiasmin-debug-apk", unzip, and install app-debug.apk on your phone (allow installs from this source).

## Or with Android Studio
Open this folder, let Gradle sync, then Build > Build APK(s). The APK is in app/build/outputs/apk/debug/.

Do not commit API keys. Keys are typed in the app and kept in memory only.

## v1.1
- ChatGPT-style chat: input pill at the bottom (+ photo, mic, send), Home next to Chat in the bottom bar.
- Modes: Auto / Text / Photo / Video. Every enabled API answers; text answers are merged into one.
- Photo: Gemini, OpenRouter, DeepInfra, Hugging Face, or any custom API. Video: Gemini Veo (paid).
- Settings > Add another API: any OpenAI-compatible service, as many as you want.
