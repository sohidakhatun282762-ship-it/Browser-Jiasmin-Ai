package com.jiasmin.browser

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var ui: WebView
    private lateinit var page: WebView
    private lateinit var overlay: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var progress: ProgressBar

    // Only the bundled Jiasmin page gets this bridge. Websites in the browser view never see it.
    inner class Bridge {
        @JavascriptInterface
        fun openUrl(u: String) {
            runOnUiThread {
                val s = Uri.parse(u).scheme
                if (s == "https" || s == "http") {
                    overlay.visibility = View.VISIBLE
                    page.loadUrl(u)
                }
            }
        }
    }

    private fun closePage() {
        overlay.visibility = View.GONE
        page.loadUrl("about:blank")
    }

    private fun btn(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 22f
        setTextColor(Color.parseColor("#1B1530"))
        gravity = Gravity.CENTER
        setPadding(36, 20, 36, 20)
        setOnClickListener { action() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)

        ui = WebView(this)
        ui.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = false
            // Lets the bundled page call AI provider APIs. Only our own local file is loaded here.
            allowUniversalAccessFromFileURLs = true
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        ui.addJavascriptInterface(Bridge(), "JiasminNative")
        ui.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                if (u.scheme == "file") return false
                Bridge().openUrl(u.toString())
                return true
            }
        }

        page = WebView(this)
        page.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        page.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val s = request?.url?.scheme
                return !(s == "https" || s == "http")
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                val h = Uri.parse(url ?: "").host ?: ""
                titleView.text = "Jiasmin Search\n" + h
            }
        }
        page.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }
        }

        titleView = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#1B1530"))
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#F4F1FB"))
            gravity = Gravity.CENTER_VERTICAL
            addView(btn("\u2715") { closePage() })
            addView(btn("\u2039") { if (page.canGoBack()) page.goBack() })
            addView(btn("\u203A") { if (page.canGoForward()) page.goForward() })
            addView(android.widget.ImageView(this@MainActivity).apply { setImageResource(R.mipmap.ic_launcher) }, LinearLayout.LayoutParams(84, 84))
            addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(btn("\u21BB") { page.reload() })
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            visibility = View.GONE
            addView(bar)
            addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 8))
            addView(page, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        root.addView(ui, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    overlay.visibility == View.VISIBLE -> if (page.canGoBack()) page.goBack() else closePage()
                    ui.canGoBack() -> ui.goBack()
                    else -> finish()
                }
            }
        })
        ui.loadUrl("file:///android_asset/index.html")
    }
}
